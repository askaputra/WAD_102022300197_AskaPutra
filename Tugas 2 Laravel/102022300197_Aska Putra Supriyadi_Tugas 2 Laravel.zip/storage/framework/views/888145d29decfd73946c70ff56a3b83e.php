<!DOCTYPE html>
<html>
<head>
    <title>Daftar Minuman</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .logout {
            position: absolute;
            top: 20px;
            right: 30px;
        }
        table {
            border-collapse: collapse;
            width: 60%;
            margin: 30px auto;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px 15px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <div class="logout">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">Logout</button>
        </form>
    </div>

    <h1>Daftar Minuman</h1>
    <table>
        <thead>
            <tr>
                <th>Nama Minuman</th>
                <th>Harga (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($drink->name); ?></td>
                    <td><?php echo e(number_format($drink->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\Aska Putra\Documents\PRAKTIKUM WAD\Tugas Laravel 11\WAD_102022300197_AskaPutra\Tugas 2 Laravel\resources\views/drinks/index.blade.php ENDPATH**/ ?>