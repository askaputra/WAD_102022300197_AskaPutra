<!DOCTYPE html>
<html>
<head>
    <title>Daftar Minuman</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table {
            border-collapse: collapse;
            width: 60%;
            margin: 30px auto;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px 15px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <h1>Daftar Minuman</h1>
    <table>
        <thead>
            <tr>
                <th>Nama Minuman</th>
                <th>Harga (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($drink->name); ?></td>
                    <td><?php echo e(number_format($drink->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\Aska Putra\Documents\PRAKTIKUM WAD\laravel11\laravel11-drinks-app\resources\views/drinks/index.blade.php ENDPATH**/ ?>